// lib/pages/settings_page.dart
// ignore_for_file: deprecated_member_use

import 'package:fermentacraft/widgets/show_paywall.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fermentacraft/utils/snacks.dart';
import 'package:fermentacraft/services/feature_gate.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../utils/boxes.dart';
import '../utils/data_management.dart';
import '../models/settings_model.dart';
import 'package:fermentacraft/services/firestore_sync_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  // --- helpers ---------------------------------------------------------------

  Widget _sectionTitle(String title, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 8),
      child: Text(title, style: Theme.of(context).textTheme.titleLarge),
    );
  }

  void _upsell(BuildContext context, String reason) {
    // You can also pass the reason into your paywall if you want.
    showPaywall(context);
  }

  // Popular currency symbols. Use a sentinel for the "Custom…" item.
  static const String _kCustomCurrency = '__CUSTOM__';
  static final List<String> _kCommonCurrencies = <String>[
    r'$',
    '€',
    '£',
    '₹',
    '¥',
    '₩',
    'R\$',
    '₱',
  ];

  // Prompts user for a custom currency symbol (1–4 visible chars is reasonable).
  Future<void> _promptCustomCurrencySymbol(SettingsModel settings) async {
    final controller = TextEditingController(text: settings.currencySymbol);
    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Custom currency'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(
            hintText: 'Enter a symbol (e.g. kr, CHF, ₪)',
          ),
          maxLength: 4,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );

    if (result != null && result.isNotEmpty) {
      await settings.setCurrencySymbol(result);
    }
  }

  // --- cards -----------------------------------------------------------------

  Widget _cloudSyncCard({
    required FeatureGate fg,
    required FirestoreSyncService sync,
    required User? user,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ListTile(
              contentPadding: const EdgeInsets.all(12.0),
              leading: const Icon(Icons.person_outline),
              title: Text(
                user == null
                    ? "Signed in as: Not signed in"
                    : "Signed in as: ${user.email ?? "Signed in"}",
              ),
              subtitle: Text(
                user == null ? "Sign in to enable online sync across devices." : "",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            const SizedBox(height: 4),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text("Enable Sync"),
              subtitle: const Text(
                "Sync recipes, batches, inventory, shopping list, tags, and settings",
              ),
              value: fg.allowSync ? sync.isEnabled : false, // force OFF if free
              onChanged: (v) async {
                if (!fg.allowSync) {
                  _upsell(context, "Cloud Sync is a Premium feature");
                  return;
                }
                if (v && user == null) {
                  snacks.show(
                    const SnackBar(content: Text("Please sign in to enable sync.")),
                  );
                  return;
                }

                final messenger = snacks;
                // Persist the preference
                Hive.box(Boxes.settings).put('syncEnabled', v);

                setState(() {
                  sync.isEnabled = v;
                });

                if (v) {
                  await sync.init();      // ensure listeners are wired
                  await sync.forceSync(); // optional initial merge
                  if (!mounted) return;
                  messenger.show(
                    const SnackBar(content: Text("Sync enabled. Merging changes…")),
                  );
                } else {
                  // If your service exposes a stop(), you can call it here.
                  messenger.show(
                    const SnackBar(content: Text("Sync disabled.")),
                  );
                }
              },
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: (fg.allowSync && user != null && sync.isEnabled)
                      ? () {
                          snacks.show(
                            const SnackBar(content: Text('Sync queued…')),
                          );
                          sync.forceSync();
                        }
                      : () {
                          if (!fg.allowSync) {
                            _upsell(context, "Cloud Sync is a Premium feature");
                          } else if (user == null) {
                            snacks.show(
                              const SnackBar(content: Text('Please sign in to sync.')),
                            );
                          } else {
                            snacks.show(
                              const SnackBar(content: Text('Enable Sync first.')),
                            );
                          }
                        },
                  icon: const Icon(Icons.sync),
                  label: const Text("Sync now"),
                ),
                const SizedBox(width: 12),
                if (user == null)
                  const Expanded(
                    child: Text(
                      "Tip: Sign in to enable syncing.",
                      textAlign: TextAlign.right,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _unitsCard(SettingsModel settings) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text("Temperature Unit"),
            const SizedBox(height: 8),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: true, label: Text("Celsius (°C)")),
                ButtonSegment(value: false, label: Text("Fahrenheit (°F)")),
              ],
              selected: {settings.useCelsius},
              onSelectionChanged: (Set<bool> newSelection) {
                settings.setUnit(isCelsius: newSelection.first);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _currencyCard(SettingsModel settings) {
    // Build item list: ensure current symbol is present even if custom.
    final List<String> items = [..._kCommonCurrencies];
    if (!items.contains(settings.currencySymbol)) {
      items.insert(0, settings.currencySymbol);
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Currency"),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              initialValue: settings.currencySymbol,
              decoration: const InputDecoration(
                labelText: 'Currency symbol',
                border: OutlineInputBorder(),
              ),
              items: [
                ...items.map((s) => DropdownMenuItem(value: s, child: Text(s))),
                const DropdownMenuItem(
                  value: _kCustomCurrency,
                  child: Text('Custom…'),
                ),
              ],
              onChanged: (selected) async {
                if (selected == null) return;
                if (selected == _kCustomCurrency) {
                  await _promptCustomCurrencySymbol(settings);
                } else {
                  await settings.setCurrencySymbol(selected);
                }
              },
            ),
            const SizedBox(height: 8),
            Text(
              'Example: ${settings.currencySymbol}12.34',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  Widget _appearanceCard(SettingsModel settings) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text("Theme"),
            const SizedBox(height: 8),
            SegmentedButton<ThemeMode>(
              segments: const [
                ButtonSegment(value: ThemeMode.light,  label: Text("Light"),  icon: Icon(Icons.wb_sunny)),
                ButtonSegment(value: ThemeMode.dark,   label: Text("Dark"),   icon: Icon(Icons.nightlight_round)),
                ButtonSegment(value: ThemeMode.system, label: Text("System"), icon: Icon(Icons.settings_suggest)),
              ],
              selected: {settings.themeMode},
              onSelectionChanged: (Set<ThemeMode> newSelection) {
                settings.changeTheme(newSelection.first);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _dataManagementCard(FeatureGate fg) {
    return Card(
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.upload_file),
            title: const Text("Export Data"),
            subtitle: const Text("Save a backup of all your recipes and inventory."),
            onTap: () {
              if (!fg.allowDataExport) {
                _upsell(context, "Export is a Premium feature");
                return;
              }
              DataManagementService.exportData(context);
            },
          ),
          ListTile(
            leading: const Icon(Icons.download_for_offline),
            title: const Text("Import Data"),
            subtitle: const Text("Restore from a backup file."),
            onTap: () => DataManagementService.importData(context),
          ),
        ],
      ),
    );
  }

  Widget _dangerZoneCard() {
  final theme = Theme.of(context);
  final container = theme.colorScheme.errorContainer;
  final onContainer = theme.colorScheme.onErrorContainer;

  return Card(
    color: container,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(12),
      side: BorderSide(color: theme.colorScheme.error.withOpacity(0.35)),
    ),
    child: ListTile(
      leading: Icon(Icons.warning_amber_rounded, color: onContainer),
      title: Text(
        "Clear All Data",
        style: theme.textTheme.titleMedium?.copyWith(color: onContainer),
      ),
      subtitle: Text(
        "Deletes all recipes, batches, inventory, tags, and settings.",
        style: theme.textTheme.bodySmall?.copyWith(
          color: onContainer.withOpacity(0.9),
        ),
      ),
      onTap: () {
        showDialog(
          context: context,
          builder: (context) {
            final t = Theme.of(context);
            return AlertDialog(
              title: const Text("Are you sure?"),
              content: const Text(
                "This action is irreversible and will delete all of your data.",
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Cancel"),
                ),
                // delete button moved to use themed error colors
                ElevatedButton.icon(
                  icon: const Icon(Icons.delete_forever),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: t.colorScheme.error,
                    foregroundColor: t.colorScheme.onError,
                  ),
                  onPressed: () async {
                    final navigator = Navigator.of(context);
                    final messenger = snacks;
                    await DataManagementService.clearAllData();
                    if (!mounted) return;
                    navigator.pop();
                    messenger.show(
                      const SnackBar(content: Text("All data has been cleared.")),
                    );
                  },
                  label: const Text("Delete Everything"),
                ),
              ],
            );
          },
        );
      },
    ),
  );
}


  // --- build -----------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsModel>();
    final sync = FirestoreSyncService.instance;
    final user = FirebaseAuth.instance.currentUser;
    final fg = context.watch<FeatureGate>();

    return Scaffold(
      appBar: AppBar(title: const Text("Settings")),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _sectionTitle("Cloud Sync", context),
          _cloudSyncCard(fg: fg, sync: sync, user: user),

          _sectionTitle("Units", context),
          _unitsCard(settings),

          _sectionTitle("Currency", context),
          _currencyCard(settings),

          _sectionTitle("Appearance", context),
          _appearanceCard(settings),

          _sectionTitle("Data Management", context),
          _dataManagementCard(fg),

          _sectionTitle("Danger Zone", context),
          _dangerZoneCard(),
        ],
      ),
    );
  }
}
