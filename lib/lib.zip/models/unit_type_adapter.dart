import 'unit_type.dart';
import 'package:hive/hive.dart';


/// Register this *once* in setup before opening boxes.
/// Pick a typeId that does not collide with your existing adapters.
/// Keep this number stable forever once shipped.
class UnitTypeAdapter extends TypeAdapter<UnitType> {
  @override
  final int typeId = 101; // choose an unused id in your app

  @override
  UnitType read(BinaryReader reader) {
    final byte = reader.readByte();
    if (byte < 0 || byte >= UnitType.values.length) {
      // Fallback if old/unknown value: default to mass (or whatever makes sense)
      return UnitType.mass;
    }
    return UnitType.values[byte];
    // If you prefer storing as String instead, use reader.readString() and parse.
  }

  @override
  void write(BinaryWriter writer, UnitType obj) {
    writer.writeByte(obj.index);
    // If you prefer string storage: writer.writeString(describeEnum(obj));
  }
}
