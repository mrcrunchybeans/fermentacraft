// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'recipe_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class RecipeModelAdapter extends TypeAdapter<RecipeModel> {
  @override
  final int typeId = 4;

  @override
  RecipeModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };

    final obj = RecipeModel(
      id: fields[0] as String?,
      name: fields[1] as String,
      createdAt: fields[2] as DateTime,
      // Seed legacy tags via constructor param so older records still load.
      tags: (fields[3] as List?)?.cast<Tag>(),
      og: (fields[4] as num?)?.toDouble(),
      fg: (fields[5] as num?)?.toDouble(),
      abv: (fields[6] as num?)?.toDouble(),
      additives: (fields[7] as List?)?.cast<Map>(),
      ingredients: (fields[8] as List?)?.cast<Map>(),
      fermentationStages:
          (fields[9] as List?)?.cast<FermentationStage>(),
      yeast: (fields[10] as List?)?.cast<Map>(),
      notes: fields[11] as String? ?? '',
      lastOpened: fields[12] as DateTime?,
      batchVolume: (fields[13] as num?)?.toDouble(),
      plannedOg: (fields[14] as num?)?.toDouble(),
      plannedAbv: (fields[15] as num?)?.toDouble(),
      isArchived: fields[16] as bool? ?? false,
    );

    // Restore refs-based tags if present.
    obj.tagRefs = fields[17] as HiveList<Tag>?;

    return obj;
  }

  @override
  void write(BinaryWriter writer, RecipeModel obj) {
    writer
      ..writeByte(18) // total number of distinct @HiveField indices written
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.name)
      ..writeByte(2)
      ..write(obj.createdAt)
      ..writeByte(3)
      ..write(obj.tagsLegacy)
      ..writeByte(4)
      ..write(obj.og)
      ..writeByte(5)
      ..write(obj.fg)
      ..writeByte(6)
      ..write(obj.abv)
      ..writeByte(7)
      ..write(obj.additives)
      ..writeByte(8)
      ..write(obj.ingredients)
      ..writeByte(9)
      ..write(obj.fermentationStages)
      ..writeByte(10)
      ..write(obj.yeast)
      ..writeByte(11)
      ..write(obj.notes)
      ..writeByte(12)
      ..write(obj.lastOpened)
      ..writeByte(13)
      ..write(obj.batchVolume)
      ..writeByte(14)
      ..write(obj.plannedOg)
      ..writeByte(15)
      ..write(obj.plannedAbv)
      ..writeByte(16)
      ..write(obj.isArchived)
      ..writeByte(17)
      ..write(obj.tagRefs);
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RecipeModelAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;

  @override
  int get hashCode => typeId.hashCode;
}
