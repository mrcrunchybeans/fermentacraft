// lib/services/yeast_repo.dart
import 'package:hive_flutter/hive_flutter.dart';
import '../models/user_yeast.dart';

class YeastRepo {
  static const userBox = 'user_yeasts';
  static const recentBox = 'recent_yeasts'; // Box<String> of names
  static const int maxRecent = 8;

  Future<Box<UserYeast>> _user() async => Hive.openBox<UserYeast>(userBox);
  Future<Box<String>> _recent() async => Hive.openBox<String>(recentBox);

  Future<List<UserYeast>> allUser() async {
    final b = await _user();
    return b.values.toList()
      ..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
  }

  Future<void> upsertByName(UserYeast y) async {
    final b = await _user();
    final lc = y.name.trim().toLowerCase();
    final key = b.keys.firstWhere(
      (k) => (b.get(k)?.name.trim().toLowerCase() ?? '') == lc,
      orElse: () => null,
    );
    if (key == null) {
      await b.add(y);
    } else {
      final existing = b.get(key)!;
      existing
        ..notes = y.notes ?? existing.notes
        ..minTempC = y.minTempC ?? existing.minTempC
        ..maxTempC = y.maxTempC ?? existing.maxTempC;
      await existing.save();
    }
  }

  Future<void> addRecent(String name) async {
    final r = await _recent();
    final lc = name.trim();
    // de-dupe
    final existingKey = r.keys.firstWhere(
      (k) => r.get(k) == lc,
      orElse: () => null,
    );
    if (existingKey == null) {
      await r.add(lc);
    }
    // trim to maxRecent (keep newest at end)
    while (r.length > maxRecent) {
      await r.delete(r.keys.first);
    }
  }

  Future<List<String>> allRecent() async {
    final r = await _recent();
    return r.values.toList().reversed.toList(); // newest first
  }
}
