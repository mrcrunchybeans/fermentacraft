// lib/services/firestore_paths.dart
import 'package:cloud_firestore/cloud_firestore.dart';

typedef JsonMap = Map<String, dynamic>;

class FirestorePaths {
  // Generic user subcollections allowed by rules: recipes, batches, inventory, shopping_list, tags
  static CollectionReference<JsonMap> coll(String uid, String name) =>
      FirebaseFirestore.instance.collection('users').doc(uid).collection(name);

  static DocumentReference<JsonMap> doc(String uid, String name, String id) =>
      coll(uid, name).doc(id);

  // ✅ A single settings doc at /users/{uid}/settings/app
  static DocumentReference<JsonMap> settingsDoc(String uid) =>
      FirebaseFirestore.instance.collection('users').doc(uid).collection('settings').doc('app');

  // Optional: premium mirror (read-only) at /users/{uid}/premium/status (allowed by your rules)
  static DocumentReference<JsonMap> premiumStatusDoc(String uid) =>
      FirebaseFirestore.instance.collection('users').doc(uid).collection('premium').doc('status');
}
