import 'package:fermentacraft/models/purchase_transaction.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../firebase_options.dart';
import '../utils/boxes.dart';

// If you have adapters, keep registering them here
// (comment out ones you don't use)
import 'package:fermentacraft/models/batch_model.dart';
import 'package:fermentacraft/models/inventory_item.dart';
import 'package:fermentacraft/models/recipe_model.dart';
import 'package:fermentacraft/models/shopping_list_item.dart';
import 'package:fermentacraft/models/tag.dart';
import 'package:fermentacraft/models/unit_type_adapter.dart';


Future<void> setupAppServices() async {
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Optional but nice to have
  try {
    FirebaseFirestore.instance.settings =
        const Settings(persistenceEnabled: true);
  } catch (_) {}

  // Hive everywhere
  await Hive.initFlutter();

  // Register adapters you actually have
  Hive
    ..registerAdapter(BatchModelAdapter())
    ..registerAdapter(InventoryItemAdapter())
    ..registerAdapter(RecipeModelAdapter())
    ..registerAdapter(ShoppingListItemAdapter())
    ..registerAdapter(TagAdapter())
    ..registerAdapter(UnitTypeAdapter())
    ..registerAdapter(PurchaseTransactionAdapter())
    ..registerAdapter(InventoryItemAdapter());


  // Open ALL boxes you reference anywhere:
  await Hive.openBox<BatchModel>(Boxes.batches);
  await Hive.openBox<InventoryItem>(Boxes.inventory);
  await Hive.openBox(Boxes.inventoryActions); // dynamic (no adapter)
  await Hive.openBox<RecipeModel>(Boxes.recipes);
  await Hive.openBox(Boxes.settings); // dynamic settings map
  await Hive.openBox<ShoppingListItem>(Boxes.shoppingList);
  await Hive.openBox(Boxes.syncMeta); // dynamic
  await Hive.openBox<Tag>(Boxes.tags);

  // Optional sanity checks in debug:
  assert(Hive.isBoxOpen(Boxes.batches));
  assert(Hive.isBoxOpen(Boxes.inventory));
  assert(Hive.isBoxOpen(Boxes.inventoryActions));
  assert(Hive.isBoxOpen(Boxes.recipes));
  assert(Hive.isBoxOpen(Boxes.settings));
  assert(Hive.isBoxOpen(Boxes.shoppingList));
  assert(Hive.isBoxOpen(Boxes.syncMeta));
  assert(Hive.isBoxOpen(Boxes.tags));
}
