// lib/widgets/additives_section.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import 'package:fermentacraft/controllers/recipe_builder_controller.dart';
import 'package:fermentacraft/services/presets_service.dart';

class AdditivesSection extends StatelessWidget {
  const AdditivesSection({super.key});

  @override
  Widget build(BuildContext context) {
    // Ensure presets are loaded (safe to call every build).
    context.read<PresetsService>().ensureLoaded();

    return Selector<RecipeBuilderController, List<AdditiveLine>>(
      selector: (_, c) => List<AdditiveLine>.from(c.additives),
      builder: (ctx, adds, _) {
        final presets = context.watch<PresetsService>().allAdditivePresets;

        return Card(
          margin: const EdgeInsets.symmetric(vertical: 6),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'Additives',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                    ),
                    FilledButton.icon(
                      icon: const Icon(Icons.add),
                      label: const Text('Add additive'),
                      onPressed: () => _openAdditiveSheet(context, presets: presets),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                if (adds.isEmpty)
                  Text(
                    'No additives added yet.',
                    style: TextStyle(color: Colors.grey.shade600),
                  )
                else
                  ...adds.map(
                    (a) => _AdditiveRow(
                      a: a,
                      onEdit: () => _openAdditiveSheet(context, editing: a, presets: presets),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _openAdditiveSheet(
    BuildContext context, {
    AdditiveLine? editing,
    required List<String> presets,
  }) async {
    final presetService = context.read<PresetsService>();

    final AdditiveLine? result = await showModalBottomSheet<AdditiveLine>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (sheetCtx) => _AdditiveEditorSheet(
        editing: editing,
        presets: presets,
        onSavePreset: presetService.maybeAddAdditivePreset,
      ),
    );

    // Guard the *same* BuildContext after the await.
    if (!context.mounted) return;

    if (result != null) {
      final ctrl = context.read<RecipeBuilderController>();
      if (editing == null) {
        ctrl.addAdditive(result);
      } else {
        ctrl.updateAdditive(editing.id, result);
      }
    }
  }
}

class _AdditiveRow extends StatelessWidget {
  final AdditiveLine a;
  final VoidCallback onEdit;
  const _AdditiveRow({required this.a, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    final ctrl = context.read<RecipeBuilderController>();
    final qty = (a.quantity == null) ? '' : '${_fmt(a.quantity!)} ${a.unit.label}';
    final when = (a.when == null || a.when!.isEmpty) ? '' : ' • ${a.when}';

    return ListTile(
      dense: true,
      title: Text(a.name.isEmpty ? 'Additive' : a.name),
      subtitle: Text('${qty.isEmpty ? '' : qty}$when'),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            tooltip: 'Edit',
            icon: const Icon(Icons.edit),
            onPressed: onEdit,
          ),
          IconButton(
            tooltip: 'Remove',
            icon: const Icon(Icons.delete_outline),
            onPressed: () => ctrl.removeAdditive(a.id),
          ),
        ],
      ),
    );
  }

  String _fmt(double v) {
    final s = v.toStringAsFixed(3);
    return s.replaceFirst(RegExp(r'\.?0+$'), '');
  }
}

/// Dedicated widget that owns the TextEditingControllers.
/// Avoids “controller used after dispose” races in sheets.
class _AdditiveEditorSheet extends StatefulWidget {
  final AdditiveLine? editing;
  final List<String> presets;
  final Future<void> Function(String) onSavePreset;

  const _AdditiveEditorSheet({
    required this.editing,
    required this.presets,
    required this.onSavePreset,
  });

  @override
  State<_AdditiveEditorSheet> createState() => _AdditiveEditorSheetState();
}

class _AdditiveEditorSheetState extends State<_AdditiveEditorSheet> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _qtyCtrl;
  late final TextEditingController _whenCtrl;
  late final TextEditingController _notesCtrl;

  late QtyUnit _unit;

  @override
  void initState() {
    super.initState();
    final e = widget.editing;
    _nameCtrl = TextEditingController(text: e?.name ?? '')
      ..addListener(() => setState(() {})); // Rebuild to enable/disable Save
    _qtyCtrl = TextEditingController(text: e?.quantity == null ? '' : _trim(e!.quantity!));
    _whenCtrl = TextEditingController(text: e?.when ?? '');
    _notesCtrl = TextEditingController(text: e?.notes ?? '');
    _unit = e?.unit ?? QtyUnit.g;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _qtyCtrl.dispose();
    _whenCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final viewInsets = MediaQuery.of(context).viewInsets;
    final height = MediaQuery.of(context).size.height;
    final maxH = height * 0.9;
    final canSave = _nameCtrl.text.trim().isNotEmpty;

    return AnimatedPadding(
      duration: const Duration(milliseconds: 200),
      padding: EdgeInsets.only(bottom: viewInsets.bottom),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: maxH),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Grab handle
              Container(
                width: 48,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey.shade400,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(height: 12),

              // Name
              TextField(
                controller: _nameCtrl,
                autofocus: true,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Additive',
                  hintText: 'e.g., Yeast nutrient',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
              const SizedBox(height: 12),

              // Quantity + Unit
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _qtyCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [
                        FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*')),
                      ],
                      decoration: const InputDecoration(
                        labelText: 'Quantity',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      textInputAction: TextInputAction.next,
                      onSubmitted: (_) => FocusScope.of(context).nextFocus(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 130,
                    child: DropdownButtonFormField<QtyUnit>(
                      value: _unit,
                      items: QtyUnit.values
                          .map((u) => DropdownMenuItem(value: u, child: Text(u.label)))
                          .toList(),
                      onChanged: (u) => setState(() => _unit = u ?? _unit),
                      decoration: const InputDecoration(
                        labelText: 'Unit',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // When
              TextField(
                controller: _whenCtrl,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'When (e.g., primary, stabilization)',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
              const SizedBox(height: 12),

              // Preset chips (built-ins + saved)
              Align(
                alignment: Alignment.centerLeft,
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final n in widget.presets)
                      ActionChip(
                        label: Text(n, overflow: TextOverflow.ellipsis),
                        onPressed: () {
                          _nameCtrl.text = n;                 // autopopulate
                          FocusScope.of(context).nextFocus();  // move to qty
                        },
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 12),

              // Notes
              TextField(
                controller: _notesCtrl,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) async {
                  if (canSave) await _commit(); // Optional: submit via keyboard
                },
                decoration: const InputDecoration(
                  labelText: 'Notes (optional)',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                maxLines: 2,
              ),

              const SizedBox(height: 12),

              // Actions
              Row(
                children: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Cancel'),
                  ),
                  const Spacer(),
                  FilledButton.icon(
                    icon: const Icon(Icons.check),
                    label: Text(widget.editing == null ? 'Add Additive' : 'Save'),
                    onPressed: canSave ? _commit : null,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _commit() async {
    final name = _nameCtrl.text.trim();
    final qty = double.tryParse(_qtyCtrl.text.trim());
    final when = _whenCtrl.text.trim().isEmpty ? null : _whenCtrl.text.trim();
    final notes = _notesCtrl.text.trim().isEmpty ? null : _notesCtrl.text.trim();

    // Save custom name for future chips
    await widget.onSavePreset(name);

    // Guard State.context right after the await
    if (!mounted) return;

    final line = AdditiveLine(
      id: widget.editing?.id ?? '',
      name: name,
      quantity: qty,
      unit: _unit,
      when: when,
      notes: notes,
    );

    Navigator.of(context).pop(line);
  }

  String _trim(double v) {
    final s = v.toStringAsFixed(3);
    return s.replaceFirst(RegExp(r'\.?0+$'), '');
  }
}
