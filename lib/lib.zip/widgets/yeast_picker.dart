// lib/widgets/yeast_picker.dart
import 'package:flutter/material.dart';
import '../services/yeast_repo.dart';
import '../models/user_yeast.dart';

typedef BuiltInYeastProvider = List<String> Function();

class YeastPicker extends StatefulWidget {
  final String? value;
  final ValueChanged<String> onChanged;
  final BuiltInYeastProvider builtInProvider;
  final String label;
  final String? hint;
  final bool allowNew;

  const YeastPicker({
    super.key,
    required this.onChanged,
    required this.builtInProvider,
    this.value,
    this.label = 'Yeast',
    this.hint,
    this.allowNew = true,
  });

  @override
  State<YeastPicker> createState() => _YeastPickerState();
}

class _YeastPickerState extends State<YeastPicker> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();
  final _repo = YeastRepo();

  List<String> _builtIn = const [];
  List<String> _recents = const [];
  List<String> _user = const [];

  @override
  void initState() {
    super.initState();
    _controller.text = widget.value ?? '';
    _loadAll();
  }

  @override
  void didUpdateWidget(covariant YeastPicker oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.value != oldWidget.value && widget.value != _controller.text) {
      _controller.text = widget.value ?? '';
    }
  }

  Future<void> _loadAll() async {
    final builtIn = widget.builtInProvider()
      ..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    final userModels = await _repo.allUser();
    final user = userModels.map((e) => e.name).toList();
    final recents = await _repo.allRecent();

    setState(() {
      _builtIn = builtIn;
      _user = user;
      _recents = recents;
    });
  }

  List<_Option> _optionsForQuery(String q) {
    final query = q.trim().toLowerCase();
    bool matches(String s) => s.toLowerCase().contains(query);

    final recentOpts = _recents.where(matches).toSet().toList()..sort();
    final userOpts = _user.where(matches).toSet().toList()..sort();
    final builtOpts = _builtIn.where(matches).toSet().toList()..sort();

    final List<_Option> out = [];
    if (recentOpts.isNotEmpty) {
      out.add(_Option.section('Recent'));
      out.addAll(recentOpts.map(_Option.value));
    }
    if (userOpts.isNotEmpty) {
      out.add(_Option.section('My Yeasts'));
      out.addAll(userOpts.map(_Option.value));
    }
    if (builtOpts.isNotEmpty) {
      out.add(_Option.section('Built-in'));
      out.addAll(builtOpts.map(_Option.value));
    }
    return out;
  }

  Future<void> _selectValue(String name) async {
    _controller.text = name;
    widget.onChanged(name);
    await _repo.addRecent(name);
    await _loadAll();
  }

  Future<void> _saveNewYeast(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    await _repo.upsertByName(UserYeast(name: trimmed));
    await _repo.addRecent(trimmed);
    await _loadAll();
    _selectValue(trimmed);
  }

  Future<void> _confirmSave(BuildContext context, String name) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Save custom yeast?'),
        content: Text('Add “$name” to My Yeasts so you can select it later?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
        ],
      ),
    );
    if (ok == true) await _saveNewYeast(name);
  }

  @override
  Widget build(BuildContext context) {
    return Autocomplete<_Option>(
      optionsBuilder: (textEditingValue) {
        final text = textEditingValue.text;
        if (text.isEmpty) return _optionsForQuery('');
        return _optionsForQuery(text);
      },
      displayStringForOption: (opt) => opt.value ?? '',
      fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
        // Use our controller/focus so external value changes stay in sync.
        return TextFormField(
          controller: _controller,
          focusNode: _focusNode,
          decoration: InputDecoration(
            labelText: widget.label,
            hintText: widget.hint ?? 'Start typing (e.g., 71B, EC-1118)',
            suffixIcon: _buildSuffix(),
          ),
          onFieldSubmitted: (_) => onFieldSubmitted(),
        );
      },
      optionsViewBuilder: (context, onSelected, options) {
        final opts = options.toList();
        final typed = _controller.text.trim();
        final canCreate = widget.allowNew &&
            typed.isNotEmpty &&
            !opts.any((o) => !o.isSection && o.value!.toLowerCase() == typed.toLowerCase());

        return Material(
          elevation: 4,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 320, minWidth: 320),
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: opts.length + (canCreate ? 1 : 0),
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (ctx, index) {
                if (canCreate && index == opts.length) {
                  return ListTile(
                    leading: const Icon(Icons.add),
                    title: Text('Create “$typed”'),
                    onTap: () => _saveNewYeast(typed),
                  );
                }
                final opt = opts[index];
                if (opt.isSection) {
                  return Padding(
                    padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                    child: Text(
                      opt.section!,
                      style: Theme.of(context).textTheme.labelMedium!.copyWith(
                            color: Theme.of(context).textTheme.bodySmall!.color?.withValues(alpha:0.7),
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                  );
                }
                return ListTile(
                  title: Text(opt.value!),
                  onTap: () => _selectValue(opt.value!),
                );
              },
            ),
          ),
        );
      },
      onSelected: (opt) {
        if (!opt.isSection && opt.value != null) _selectValue(opt.value!);
      },
    );
  }

  Widget _buildSuffix() {
    final typed = _controller.text.trim();
    final inCombined = {
      ..._builtIn.map((e) => e.toLowerCase()),
      ..._user.map((e) => e.toLowerCase()),
      ..._recents.map((e) => e.toLowerCase()),
    }.contains(typed.toLowerCase());

    if (!widget.allowNew || typed.isEmpty || inCombined) {
      return const SizedBox.shrink();
    }
    return IconButton(
      tooltip: 'Save “$typed”',
      icon: const Icon(Icons.save_alt),
      onPressed: () => _confirmSave(context, typed),
    );
  }
}

class _Option {
  final String? value;
  final String? section;
  bool get isSection => section != null;

  _Option.value(this.value) : section = null;
  _Option.section(this.section) : value = null;
}
