import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

// NEW: merged yeast picker (Built-in + My Yeasts + Recent)
import 'yeast_picker.dart';

class AddYeastDialog extends StatefulWidget {
  final Map<String, dynamic>? existing;
  final Function(Map<String, dynamic>) onAdd;
  final Function(Map<String, dynamic>)? onAddToInventory;

  const AddYeastDialog({
    super.key,
    this.existing,
    required this.onAdd,
    this.onAddToInventory,
  });

  @override
  State<AddYeastDialog> createState() => _AddYeastDialogState();
}

class _AddYeastDialogState extends State<AddYeastDialog> {
  // Built-ins you previously surfaced (add anything you like here)
  List<String> _builtInYeasts() => const [
        'Lalvin EC-1118',
        'Red Star Premier Blanc',
        'Safale US-05',
        'Wyeast 1056 American Ale',
        'Lalvin D-47',
        'Lalvin K1-V1116',
        'Nottingham Ale Yeast',
        'WLP001 California Ale',
        'Mangrove Jack’s M02 Cider',
        // users can also save customs like "71B" which will then live in "My Yeasts"
      ];

  // State
  String? _yeastName;
  final TextEditingController amountController = TextEditingController();
  final TextEditingController costController = TextEditingController();
  DateTime purchaseDate = DateTime.now();
  DateTime? expirationDate;
  String unit = 'packets';

  @override
  void initState() {
    super.initState();

    // Seed from existing
    if (widget.existing != null) {
      final y = widget.existing!;
      _yeastName = (y['name'] as String?)?.trim();

      amountController.text = (y['amount']?.toString() ?? '');
      unit = y['unit'] as String? ?? 'packets';
      costController.text = (y['cost']?.toString() ?? '');

      final pDate = y['purchaseDate'];
      if (pDate is String) {
        purchaseDate = DateTime.tryParse(pDate) ?? DateTime.now();
      } else if (pDate is DateTime) {
        purchaseDate = pDate;
      } else {
        purchaseDate = DateTime.now();
      }

      final eDate = y['expirationDate'];
      if (eDate is String) {
        expirationDate = DateTime.tryParse(eDate);
      } else if (eDate is DateTime) {
        expirationDate = eDate;
      }
    } else {
      // default to a sensible/common yeast if none selected yet
      _yeastName = _builtInYeasts().first;
    }
  }

  Map<String, dynamic> _buildYeastEntry() {
    final name = (_yeastName ?? '').trim();
    final amount = double.tryParse(amountController.text.trim()) ?? 0.0;
    final cost = double.tryParse(costController.text.trim()) ?? 0.0;

    return {
      'name': name.isEmpty ? 'Custom Yeast' : name,
      'amount': amount,
      'unit': unit,
      'cost': cost,
      'purchaseDate': purchaseDate,
      'expirationDate': expirationDate,
    };
  }

  @override
  Widget build(BuildContext context) {
    final bool isEditing = widget.existing != null;

    return AlertDialog(
      title: Text(isEditing ? "Edit Yeast" : "Add Yeast"),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Replaces your dropdown + "Other (Custom)" text field.
            // - Merges Built-in + My Yeasts + Recent
            // - Lets user create/save a new one (e.g., "71B") inline
            YeastPicker(
              value: _yeastName,
              builtInProvider: _builtInYeasts,
              onChanged: (name) => setState(() => _yeastName = name),
              label: 'Yeast',
              hint: 'Search or type a yeast (e.g., 71B)',
              allowNew: true,
            ),

            const SizedBox(height: 12),
            TextFormField(
              controller: amountController,
              decoration: const InputDecoration(labelText: "Amount"),
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: unit,
              items: const ['grams', 'packets']
                  .map((u) => DropdownMenuItem(value: u, child: Text(u)))
                  .toList(),
              onChanged: (val) {
                if (val != null) setState(() => unit = val);
              },
              decoration: const InputDecoration(labelText: "Unit"),
            ),
            const Divider(),
            TextFormField(
              controller: costController,
              decoration:
                  const InputDecoration(labelText: 'Total Cost (\$)'),
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Text(
                  "Purchase: ${DateFormat.yMMMd().format(purchaseDate)}",
                ),
                const Spacer(),
                TextButton(
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: purchaseDate,
                      firstDate: DateTime(2000),
                      lastDate: DateTime.now(),
                    );
                    if (picked != null) {
                      setState(() => purchaseDate = picked);
                    }
                  },
                  child: const Text("Change"),
                ),
              ],
            ),
            Row(
              children: [
                Text(
                  expirationDate == null
                      ? "Expiration: Not set"
                      : "Expires: ${DateFormat.yMMMd().format(expirationDate!)}",
                ),
                const Spacer(),
                TextButton(
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate:
                          expirationDate ?? DateTime.now().add(const Duration(days: 365)),
                      firstDate: DateTime.now(),
                      lastDate: DateTime(2040),
                    );
                    if (picked != null) {
                      setState(() => expirationDate = picked);
                    }
                  },
                  child: const Text("Set"),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        if (widget.onAddToInventory != null)
          TextButton(
            onPressed: () {
              final yeast = _buildYeastEntry();
              widget.onAddToInventory!(yeast);
              Navigator.of(context).pop();
            },
            child: const Text("Add to Inventory"),
          ),
        TextButton(
          onPressed: () {
            final yeast = _buildYeastEntry();
            widget.onAdd(yeast);
            Navigator.of(context).pop();
          },
          child: Text(isEditing ? "Save Changes" : "Add"),
        ),
      ],
    );
  }
}
