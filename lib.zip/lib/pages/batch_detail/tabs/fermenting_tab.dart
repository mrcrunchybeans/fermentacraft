import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:fermentacraft/models/batch_model.dart';
import 'package:fermentacraft/models/measurement.dart';
import 'package:fermentacraft/models/fermentation_stage.dart';

import 'package:fermentacraft/widgets/add_measurement_dialog.dart';
import 'package:fermentacraft/widgets/manage_stages_dialog.dart';
import 'package:fermentacraft/widgets/batch/measurements_card.dart';

import '../sections/fermentation_stages_section.dart';

class FermentingTab extends StatefulWidget {
  const FermentingTab({
    super.key,
    required this.batch,
    required this.unitLabel,
    this.firebaseUid,
    this.deviceName,
  });

  final BatchModel batch;
  final String unitLabel;
  final String? firebaseUid;
  final String? deviceName;

  @override
  State<FermentingTab> createState() => _FermentingTabState();
}

class _FermentingTabState extends State<FermentingTab>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  // ---- Unified source of truth ----------------------------------------------
  // Older app versions may not populate `batch.measurements` the same way.
  // This resolver guarantees we get everything:
  List<Measurement> _resolveAllMeasurements() {
  // Use the batch field directly
  final m = widget.batch.measurements;
  if (m.isNotEmpty) return List<Measurement>.from(m);

  // Optional: try safeMeasurements if your model provides it
  try {
    final dynamic dyn = widget.batch;
    final maybe = (dyn as dynamic).safeMeasurements as List<Measurement>?;
    if (maybe != null && maybe.isNotEmpty) {
      return List<Measurement>.from(maybe);
    }
  } catch (_) {}

  return const <Measurement>[];
}

  // Device heuristics (works for older points too)
  bool _isDevice(Measurement m) {
    if (m.fromDevice == true) return true;
    if (m.fsuspeed != null) return true; // present on device uploads
    final n = (m.notes ?? '').toLowerCase();
    if (n.contains('tilt') || n.contains('ispindel') || n.contains('plaato')) {
      return true;
    }
    return false;
  }

  IconData _batteryIconForPercent(double? p) {
    if (p == null) return Icons.battery_unknown;
    if (p >= 0.85) return Icons.battery_full;
    if (p >= 0.60) return Icons.battery_6_bar;
    if (p >= 0.40) return Icons.battery_5_bar;
    if (p >= 0.25) return Icons.battery_3_bar;
    if (p >= 0.10) return Icons.battery_2_bar;
    return Icons.battery_alert;
  }

  String _timeAgoShort(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 1) return 'just now';
    if (d.inMinutes < 60) return '${d.inMinutes}m ago';
    if (d.inHours < 24) return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }

  Future<void> _onManageStages() async {
    final updated = await showDialog<List<FermentationStage>>(
      context: context,
      builder: (_) => ManageStagesDialog(
        initialStages: widget.batch.safeFermentationStages,
        anchorStartDate: widget.batch.startDate,
      ),
    );
    if (updated != null) {
      widget.batch.fermentationStages = updated;
      await widget.batch.save();
      if (!mounted) return;
      setState(() {});
    }
  }

  // ---- measurements actions --------------------------------------------------

  Future<Measurement?> _addMeasurement(
    BuildContext context,
    Measurement? previous,
    DateTime? first,
  ) async {
    final res = await showDialog<Measurement>(
      context: context,
      builder: (_) => AddMeasurementDialog(
        previousMeasurement: previous,
        firstMeasurementDate: first,
      ),
    );
    if (res != null) {
      widget.batch.measurements.add(res);
      await widget.batch.save();
      if (mounted) setState(() {});
    }
    return res;
  }

  Future<Measurement?> _editMeasurement(
    BuildContext context,
    Measurement toEdit,
    Measurement? previous,
    DateTime? first,
  ) async {
    final res = await showDialog<Measurement>(
      context: context,
      builder: (_) => AddMeasurementDialog(
        existingMeasurement: toEdit,
        previousMeasurement: previous,
        firstMeasurementDate: first,
      ),
    );
    if (res != null) {
      final i = widget.batch.measurements.indexOf(toEdit);
      if (i >= 0) {
        widget.batch.measurements[i] = res;
      } else {
        widget.batch.measurements.add(res);
      }
      await widget.batch.save();
      if (mounted) setState(() {});
    }
    return res;
  }

  Future<void> _deleteMeasurement(Measurement m) async {
    widget.batch.measurements.remove(m);
    await widget.batch.save();
    if (mounted) setState(() {});
  }

  // ---- Recent list (merged; no cap) -----------------------------------------

  Widget _recentList(BuildContext context) {
    final all = _resolveAllMeasurements();
    final merged = [...all]..sort((a, b) => b.timestamp.compareTo(a.timestamp));

    // group by day
    final byDay = <DateTime, List<Measurement>>{};
    for (final m in merged) {
      final t = m.timestamp.toLocal();
      final key = DateTime(t.year, t.month, t.day);
      (byDay[key] ??= <Measurement>[]).add(m);
    }
    final dayKeys = byDay.keys.toList()..sort((a, b) => b.compareTo(a));

    String fmt(Measurement m) {
      final t = DateFormat.Md().add_jm().format(m.timestamp.toLocal());
      final g = (m.gravity != null)
          ? m.gravity!.toStringAsFixed(3)
          : (m.brix != null)
              ? '${m.brix!.toStringAsFixed(1)}°Bx'
              : '—';
      final temp =
          (m.temperature != null) ? '${m.temperature!.toStringAsFixed(1)}°C' : '—';
      final fsu =
          (m.fsuspeed != null) ? ' · FSU ${m.fsuspeed!.toStringAsFixed(0)}' : '';
      return '$t · SG $g · $temp$fsu';
    }

    Widget badge(Measurement m) {
      if (!_isDevice(m)) return const SizedBox.shrink();
      final label = (widget.deviceName?.trim().isNotEmpty == true)
          ? widget.deviceName!.trim()
          : ((m.notes?.trim().isNotEmpty == true) ? m.notes!.trim() : 'device');
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(label),
      );
    }

    return SectionCard(
      title: 'Recent measurements',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final day in dayKeys) ...[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Text(
                DateFormat.MMMd().format(day),
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
            for (final m in byDay[day]!)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    Expanded(child: Text(fmt(m))),
                    const SizedBox(width: 6),
                    badge(m),
                    const SizedBox(width: 6),
                    if (!_isDevice(m))
                      IconButton(
                        tooltip: 'Edit',
                        icon: const Icon(Icons.edit),
                        onPressed: () {
                          final sorted = [..._resolveAllMeasurements()]
                            ..sort((a, b) => a.timestamp.compareTo(b.timestamp));
                          Measurement? previous;
                          for (final x in sorted) {
                            if (x.timestamp.isBefore(m.timestamp)) {
                              previous = x;
                            } else {
                              break;
                            }
                          }
                          _editMeasurement(
                            context,
                            m,
                            previous,
                            sorted.isNotEmpty ? sorted.first.timestamp : null,
                          );
                        },
                      ),
                    if (!_isDevice(m))
                      IconButton(
                        tooltip: 'Delete',
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => _deleteMeasurement(m),
                      ),
                  ],
                ),
              ),
            const Divider(height: 8),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final allForChart = _resolveAllMeasurements();

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        // 1) Chart uses the unified list
        MeasurementsCard(
          measurements: allForChart,
          stages: widget.batch.safeFermentationStages,
          onAdd: (prev, first) => _addMeasurement(context, prev, first),
          onEdit: (toEdit, prev, first) =>
              _editMeasurement(context, toEdit, prev, first),
          onDelete: _deleteMeasurement,
          onManageStages: _onManageStages,
        ),

        const SizedBox(height: 12),

        // 2) Optional device status (UID now resolved in page and passed down)
        if (widget.firebaseUid != null)
          DeviceStatusRowSection(
            uid: widget.firebaseUid!,
            batchId: widget.batch.id,
            batteryIconForPercent: _batteryIconForPercent,
            timeAgoShort: _timeAgoShort,
          ),

        if (widget.firebaseUid != null) const SizedBox(height: 12),

        // 3) Recent merged list
        _recentList(context),

        const SizedBox(height: 12),

        // 4) Stages
        SectionCard(
          title: 'Stages',
          trailing: IconButton(
            tooltip: 'Manage stages',
            icon: const Icon(Icons.tune),
            onPressed: _onManageStages,
          ),
          child: FermentationStagesSection(
            stages: widget.batch.safeFermentationStages,
            unit: widget.unitLabel,
          ),
        ),
      ],
    );
  }
}
