// lib/main.dart
import 'dart:async';
import 'package:fermentacraft/utils/inventory_item_extensions.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart' show kIsWeb;                 // ⬅️ ADD
import 'firebase_options.dart';
import 'auth_gate.dart';

// Models / Hive adapters
import 'services/feature_gate.dart';
import 'services/revenuecat_service.dart';
import 'services/firestore_sync_service.dart';
import 'services/auth_service.dart';                                   // ⬅️ ADD

import 'models/batch_model.dart';
import 'models/fermentation_stage.dart';
import 'models/inventory_item.dart';
import 'models/inventory_transaction_model.dart';
import 'models/measurement.dart';
import 'models/measurement_log.dart';
import 'models/planned_event.dart';
import 'models/recipe_model.dart';
import 'models/shopping_list_item.dart';
import 'models/tag.dart';
import 'models/purchase_transaction.dart';
import 'models/unit_type.dart';
import 'models/tag_manager.dart';
import 'models/settings_model.dart';
import 'utils/migrations.dart';

// Theme
import 'theme/app_theme.dart';

Future<void> setupHive() async {
  await Hive.initFlutter();

  // Register adapters BEFORE opening boxes that use them
  Hive.registerAdapter(MeasurementAdapter());
  Hive.registerAdapter(FermentationStageAdapter());
  Hive.registerAdapter(PlannedEventAdapter());
  Hive.registerAdapter(TagAdapter());
  Hive.registerAdapter(InventoryItemAdapter());
  Hive.registerAdapter(InventoryTransactionAdapter());
  Hive.registerAdapter(MeasurementLogAdapter());
  Hive.registerAdapter(RecipeModelAdapter());
  Hive.registerAdapter(ShoppingListItemAdapter());
  Hive.registerAdapter(PurchaseTransactionAdapter());
  Hive.registerAdapter(UnitTypeAdapter());
  Hive.registerAdapter(BatchModelAdapter());

  // Open boxes actually used
  await Hive.openBox<BatchModel>('batches');
  await Hive.openBox<FermentationStage>('fermentationStages');
  await Hive.openBox<InventoryItem>('inventory');
  await Hive.openBox<InventoryTransaction>('inventoryTransactions');
  await Hive.openBox<MeasurementLog>('measurementLogs');
  await Hive.openBox<RecipeModel>('recipes');
  await InventoryArchiveStore.ensureOpen(); // sidecar archive box
  await Hive.openBox('settings');
  await Hive.openBox<ShoppingListItem>('shopping_list');
  await Hive.openBox<Tag>('tags');

  // ✅ Run icon migrations AFTER the relevant boxes are open
  await migrateTagIconsIfNeeded();       // standalone 'tags' box (if used)
  await migrateEmbeddedTagsIfNeeded();   // tags embedded in recipes/batches
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // ✅ WEB-ONLY: finish Google redirect sign-in if popup was blocked
  if (kIsWeb) {
    // Don’t block app start; just let it resolve if there’s a pending redirect.
    // (If you want to be extra safe, you can `await` this.)
    AuthService.instance.completePendingRedirectIfAny();
  }

  // Configure Firestore once
  FirebaseFirestore.instance.settings = const Settings(persistenceEnabled: true);
  FirebaseFirestore.setLoggingEnabled(true);

  // Local storage
  await setupHive();

  // Start your own sync service
  await FirestoreSyncService.instance.init();

  // Configure RevenueCat once (mobile) & FeatureGate.
  await RevenueCatService.instance.init();
  await FeatureGate.instance.bootstrap();

  // Catch uncaught framework errors
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.dumpErrorToConsole(details);
  };

  await runZonedGuarded<Future<void>>(() async {
    runApp(
      MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => SettingsModel()),
          ChangeNotifierProvider(create: (_) => TagManager()),
        ],
        child: const FermentaCraftApp(),
      ),
    );
  }, (error, stack) {
    debugPrint('Uncaught zone error: $error\n$stack');
  });
}

class FermentaCraftApp extends StatelessWidget {
  const FermentaCraftApp({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsModel>();
    return MaterialApp(
      title: 'FermentaCraft',
      debugShowCheckedModeBanner: false,
      themeMode: settings.themeMode,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      home: const AuthGate(),
      builder: (context, child) => SafeArea(
        top: false,
        left: false,
        right: false,
        bottom: true,
        // keeps padding when keyboard shows so things don't jump
        maintainBottomViewPadding: true,
        child: child ?? const SizedBox.shrink(),
      ),
    );
  }
}
